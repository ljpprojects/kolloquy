# Kolloquy Markup

Note that markdown can be used. To use markdown, type `%MD`

## Emphasise

Use the syntax `<TEXT>` to italicise text.

## Shout (Bold)

Use the syntax `*TEXT*` to bold text.

## Links

Use the syntax `(DISPLAY)<LINK>` for links.

## Underline

Use the syntax `_TEXT_`

## Strikethrough

Use the syntax `-TEXT-` 